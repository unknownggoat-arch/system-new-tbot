# SystemClient 1.21.11

Fabric client mod for Minecraft 1.21.11 (Java 21).

## Build (GitHub Actions)
1. Push this repo to GitHub (the project files must be in the repo root, next to `.github/`).
2. Open the **Actions** tab → **Build** → wait for the green check.
3. Open the finished run → **Artifacts** → download `SystemClient-jar` → the `.jar` is inside.

To publish a Release with the jar attached: `git tag v1.0 && git push origin v1.0`.

## Build locally
```
./gradlew build        # Windows: gradlew.bat build
```
Jar: `build/libs/system-*.jar` (not the `-sources` one).

## Install
Fabric Loader + Fabric API `0.140.0+1.21.11`, put the jar in `.minecraft/mods`.
