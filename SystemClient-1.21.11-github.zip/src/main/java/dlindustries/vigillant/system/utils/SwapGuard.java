package dlindustries.vigillant.system.utils;

/**
 * Set while the client itself triggers an attack (e.g. SpearLunge jab), so other modules that listen
 * to AttackEvent (TriggerBot, BreachSwap, AutoMace) don't cancel it or swap items again.
 */
public final class SwapGuard {
	public static boolean internalAttack = false;

	private SwapGuard() {
	}
}
