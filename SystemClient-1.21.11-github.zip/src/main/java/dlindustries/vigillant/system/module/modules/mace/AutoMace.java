package dlindustries.vigillant.system.module.modules.mace;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.ItemSwapper;
import dlindustries.vigillant.system.utils.SwapGuard;
import dlindustries.vigillant.system.utils.WorldUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Whatever item is in your hand, when you hit a player the mace is swapped in, the hit is made with the
 * mace and the old item is swapped back afterwards.
 */
public final class AutoMace extends Module implements AttackListener, TickListener {
	private final ModeSetting<ItemSwapper.Mode> swapMode = new ModeSetting<>(EncryptedString.of("Swap Mode"), ItemSwapper.Mode.HandSwap, ItemSwapper.Mode.class)
			.setDescription(EncryptedString.of("Hand Swap: mace swaps places with the item in your hand (works from the inventory too). Hotbar: only selects the mace slot"));
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true)
			.setDescription(EncryptedString.of("Put your old item back after the hit"));
	private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0, 10, 1, 1)
			.setDescription(EncryptedString.of("Ticks to wait after the hit before switching back"));
	private final BooleanSetting onlyPlayers = new BooleanSetting(EncryptedString.of("Only Players"), true);
	private final BooleanSetting requireFall = new BooleanSetting(EncryptedString.of("Require Fall"), false)
			.setDescription(EncryptedString.of("Only swap to the mace while falling"));
	private final NumberSetting minFall = new NumberSetting(EncryptedString.of("Min Fall"), 0, 10, 1.5, 0.5)
			.setDescription(EncryptedString.of("Minimum fall distance for Require Fall"));
	private final BooleanSetting autoHit = new BooleanSetting(EncryptedString.of("Auto Hit"), false)
			.setDescription(EncryptedString.of("Also hits the player in your crosshair by itself (swap + attack)"));

	private final ItemSwapper swapper = new ItemSwapper();
	private int timer;

	public AutoMace() {
		super(EncryptedString.of("Auto Mace"),
				EncryptedString.of("Swaps the mace into your hand (whatever you hold) and hits the target"),
				-1,
				Category.mace);
		addSettings(swapMode, switchBack, switchDelay, onlyPlayers, requireFall, minFall, autoHit);
	}

	@Override
	public void onEnable() {
		eventManager.add(AttackListener.class, this);
		eventManager.add(TickListener.class, this);
		timer = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(AttackListener.class, this);
		eventManager.remove(TickListener.class, this);
		swapper.restore();
		super.onDisable();
	}

	@Override
	public void onAttack(AttackEvent event) {
		if (SwapGuard.internalAttack) return;
		if (mc.player == null || mc.currentScreen != null) return;
		if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
		if (!isValidTarget(hit.getEntity())) return;

		equipMace();
	}

	@Override
	public void onTick() {
		if (mc.player == null) return;

		if (swapper.isActive()) {
			if (timer >= switchDelay.getValueInt()) {
				swapper.restore();
			} else {
				timer++;
			}
			return;
		}

		if (autoHit.getValue() && mc.currentScreen == null) {
			autoHit();
		}
	}

	private void autoHit() {
		if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
		Entity target = hit.getEntity();
		if (!isValidTarget(target)) return;
		if (mc.player.getAttackCooldownProgress(0.5f) < 0.95f) return;

		if (equipMace()) {
			WorldUtils.hitEntity(target, true);
		}
	}

	/** @return true if the mace is in the hand now */
	private boolean equipMace() {
		if (requireFall.getValue() && mc.player.fallDistance < minFall.getValueFloat()) return false;

		if (!swapper.equip(AutoMace::maceScore, swapMode.getMode())) return false;

		if (swapper.isActive()) {
			if (switchBack.getValue()) {
				timer = 0;
			} else {
				swapper.clear();
			}
		}
		return true;
	}

	private boolean isValidTarget(Entity entity) {
		if (entity == null || entity == mc.player || !entity.isAlive()) return false;
		if (!(entity instanceof LivingEntity)) return false;
		return !onlyPlayers.getValue() || entity instanceof PlayerEntity;
	}

	private static int maceScore(ItemStack stack) {
		return !stack.isEmpty() && stack.isOf(Items.MACE) ? 1 : -1;
	}
}
