package dlindustries.vigillant.system.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayDeque;
import java.util.function.ToIntFunction;

/**
 * ONE shared swap manager for every module (AutoMace, SpearLunge, ...).
 *
 * Every swap is pushed on a stack. When the hold time is over, ALL swaps are undone in reverse order
 * (last in, first out), so the hotbar always ends exactly as it was - no matter how many modules swapped
 * in between. This is what stops the modules from shuffling each other's items around.
 */
public final class ItemSwapper {
	public enum Mode {
		HandSwap("Hand Swap"),
		Hotbar("Hotbar");

		private final String label;

		Mode(String label) {
			this.label = label;
		}

		@Override
		public String toString() {
			return label;
		}
	}

	private static final MinecraftClient mc = MinecraftClient.getInstance();

	/** {type, a, b}: type 0 = hotbar select (a = previous slot), type 1 = hand swap (a = screen slot id, b = hotbar button) */
	private static final ArrayDeque<int[]> steps = new ArrayDeque<>();
	private static int holdUntil = 0;
	private static int lastAge = -1;

	private ItemSwapper() {
	}

	public static boolean hasSwaps() {
		return !steps.isEmpty();
	}

	/** Call once per tick from every module that uses the swapper (it only acts once per game tick). */
	public static void tick() {
		if (mc.player == null) {
			steps.clear();
			lastAge = -1;
			return;
		}

		int age = mc.player.age;
		if (age == lastAge) return;
		if (age < lastAge) steps.clear(); // respawn / world change
		lastAge = age;

		if (!steps.isEmpty() && age >= holdUntil) {
			restoreAll();
		}
	}

	/**
	 * Gets a wanted item into the hand.
	 *
	 * @param scorer    -1 = not wanted, otherwise a score (higher = better)
	 * @param holdTicks how long the swap is kept before everything is swapped back (min 1)
	 * @return true if a wanted item is in the hand afterwards
	 */
	public static boolean equip(ToIntFunction<ItemStack> scorer, Mode mode, int holdTicks) {
		if (mc.player == null || mc.interactionManager == null) return false;

		PlayerInventory inv = mc.player.getInventory();
		int current = InventoryUtils.getSelectedSlot();
		int until = mc.player.age + Math.max(1, holdTicks);

		// already holding it: just keep the current swaps alive long enough
		if (scorer.applyAsInt(inv.getStack(current)) >= 0) {
			if (!steps.isEmpty()) holdUntil = Math.max(holdUntil, until);
			return true;
		}

		int best = -1;
		int bestScore = -1;
		int limit = mode == Mode.Hotbar ? 9 : 36;
		for (int i = 0; i < limit; i++) {
			int score = scorer.applyAsInt(inv.getStack(i));
			if (score > bestScore) {
				bestScore = score;
				best = i;
			}
		}
		if (best == -1) return false;

		if (mode == Mode.Hotbar) {
			steps.push(new int[]{0, current, 0});
			InventoryUtils.setSelectedSlot(best);
		} else {
			// screen handler ids: hotbar 36-44, main inventory 9-35
			int slotId = best < 9 ? 36 + best : best;
			click(slotId, current);
			steps.push(new int[]{1, slotId, current});
		}

		holdUntil = steps.size() == 1 ? until : Math.max(holdUntil, until);
		return true;
	}

	/** Undo every swap now, in reverse order. */
	public static void restoreAll() {
		if (mc.player == null || mc.interactionManager == null) {
			steps.clear();
			return;
		}
		while (!steps.isEmpty()) {
			int[] s = steps.pop();
			if (s[0] == 0) {
				InventoryUtils.setSelectedSlot(s[1]);
			} else {
				click(s[1], s[2]);
			}
		}
	}

	/** Keep the items where they are now (no swap back). */
	public static void forgetAll() {
		steps.clear();
	}

	private static void click(int slotId, int hotbarButton) {
		mc.interactionManager.clickSlot(
				mc.player.playerScreenHandler.syncId,
				slotId,
				hotbarButton,
				SlotActionType.SWAP,
				mc.player
		);
	}
}
