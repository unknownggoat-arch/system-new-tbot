package dlindustries.vigillant.system.module.modules.mace;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.mixin.MinecraftClientAccessor;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.EnchantmentUtil;
import dlindustries.vigillant.system.utils.ItemSwapper;
import dlindustries.vigillant.system.utils.KeyUtils;
import dlindustries.vigillant.system.utils.SwapGuard;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

/**
 * EVERY press of the activate key = one lunge: the spear (prefers Lunge) is swapped into your hand, the jab is made
 * (if the game refuses it, e.g. its own attack cooldown, it is retried for a few ticks) and everything is swapped back.
 */
public final class SpearLunge extends Module implements TickListener {
	private static final RegistryKey<Enchantment> LUNGE =
			RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of("minecraft", "lunge"));

	/** true while a lunge is waiting for / performing its jab (AutoMace stays out of the way) */
	private static boolean busy = false;

	private final KeybindSetting activateKey = new KeybindSetting(EncryptedString.of("Activate Key"), -1, false)
			.setDescription(EncryptedString.of("Every press = one lunge"));
	private final ModeSetting<ItemSwapper.Mode> swapMode = new ModeSetting<>(EncryptedString.of("Swap Mode"), ItemSwapper.Mode.HandSwap, ItemSwapper.Mode.class)
			.setDescription(EncryptedString.of("Hand Swap: spear swaps places with the item in your hand (works from the inventory too). Hotbar: only selects the spear slot"));
	private final BooleanSetting preferLunge = new BooleanSetting(EncryptedString.of("Prefer Lunge"), true)
			.setDescription(EncryptedString.of("Pick a spear with the Lunge enchantment first"));
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true)
			.setDescription(EncryptedString.of("Put your items back after the lunge"));
	private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0, 10, 2, 1)
			.setDescription(EncryptedString.of("Ticks to keep the spear after the jab"));
	private final NumberSetting retryTicks = new NumberSetting(EncryptedString.of("Retry Ticks"), 0, 10, 5, 1)
			.setDescription(EncryptedString.of("If the game refuses the jab, keep trying for this many ticks"));
	private final BooleanSetting holdRepeat = new BooleanSetting(EncryptedString.of("Hold Repeat"), false)
			.setDescription(EncryptedString.of("Keep lunging while the key is held"));
	private final NumberSetting repeatDelay = new NumberSetting(EncryptedString.of("Repeat Delay"), 1, 40, 10, 1)
			.setDescription(EncryptedString.of("Ticks between lunges while Hold Repeat is on"));

	private boolean wasPressed;
	private int pending;
	private int repeatTimer;

	public SpearLunge() {
		super(EncryptedString.of("Spear Lunge"),
				EncryptedString.of("Press a key: swap to spear, lunge, swap back (every press)"),
				-1,
				Category.mace);
		addSettings(activateKey, swapMode, preferLunge, switchBack, switchDelay, retryTicks, holdRepeat, repeatDelay);
	}

	public static boolean isBusy() {
		return busy;
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		wasPressed = false;
		pending = 0;
		repeatTimer = 0;
		busy = false;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		pending = 0;
		busy = false;
		ItemSwapper.restoreAll();
		super.onDisable();
	}

	@Override
	public void onTick() {
		ItemSwapper.tick();
		if (mc.player == null || mc.interactionManager == null) return;

		if (mc.currentScreen != null) {
			pending = 0;
			busy = false;
			return;
		}

		int key = activateKey.getKey();
		boolean pressed = key >= 0 && KeyUtils.isKeyPressed(key);
		boolean fresh = pressed && !wasPressed;
		wasPressed = pressed;

		if (repeatTimer > 0) repeatTimer--;

		if (fresh || (pressed && holdRepeat.getValue() && repeatTimer <= 0 && pending == 0)) {
			pending = retryTicks.getValueInt() + 1;
			repeatTimer = repeatDelay.getValueInt();
		}

		busy = pending > 0;
		if (pending <= 0) return;
		pending--;

		if (!ItemSwapper.equip(this::spearScore, swapMode.getMode(), switchDelay.getValueInt() + 1)) {
			pending = 0;
			busy = false;
			return; // no spear found
		}

		if (jab()) {
			pending = 0;
			if (!switchBack.getValue()) {
				ItemSwapper.forgetAll();
			}
		}
		busy = pending > 0;
	}

	/** Uses the game's own attack path, that is what performs the spear jab (and so the lunge). */
	private boolean jab() {
		SwapGuard.internalAttack = true;
		try {
			return ((MinecraftClientAccessor) mc).invokeDoAttack();
		} finally {
			SwapGuard.internalAttack = false;
		}
	}

	private int spearScore(ItemStack stack) {
		if (stack.isEmpty()) return -1;
		if (!Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear")) return -1;
		return preferLunge.getValue() && EnchantmentUtil.hasEnchantment(stack, LUNGE) ? 2 : 1;
	}
}
