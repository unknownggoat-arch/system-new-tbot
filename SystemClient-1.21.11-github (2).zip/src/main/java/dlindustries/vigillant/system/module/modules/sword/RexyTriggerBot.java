package dlindustries.vigillant.system.module.modules.sword;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.InventoryUtils;
import dlindustries.vigillant.system.utils.MouseSimulation;
import dlindustries.vigillant.system.utils.SwapGuard;
import dlindustries.vigillant.system.utils.WorldUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * Native port of the "Rexy Trigger Bot" settings (the pasted code only had the settings, the attack logic is
 * re-created from what each setting says).
 *
 * Timing: once the attack is charged, every tick has a random chance (Ground/Air Cooldown + Random, in %) to fire,
 * so the delay is not a fixed number.
 */
public final class RexyTriggerBot extends Module implements TickListener, AttackListener {
	public final BooleanSetting checkSword = new BooleanSetting(EncryptedString.of("Check Sword"), true)
			.setDescription(EncryptedString.of("Only attack with sword or axe"));
	public final BooleanSetting checkShield = new BooleanSetting(EncryptedString.of("Check Shield"), true)
			.setDescription(EncryptedString.of("Dont attack while blocking"));
	public final BooleanSetting checkUsing = new BooleanSetting(EncryptedString.of("Check Using"), true)
			.setDescription(EncryptedString.of("Dont attack while eating/drinking"));
	public final BooleanSetting checkScreen = new BooleanSetting(EncryptedString.of("Check Screen"), true)
			.setDescription(EncryptedString.of("Dont attack while in inventory"));
	public final BooleanSetting checkHealth = new BooleanSetting(EncryptedString.of("Check Health"), true)
			.setDescription(EncryptedString.of("Dont attack dead targets"));
	public final BooleanSetting checkFriends = new BooleanSetting(EncryptedString.of("Check Friends"), true)
			.setDescription(EncryptedString.of("Dont attack friends"));
	public final BooleanSetting onLeftClick = new BooleanSetting(EncryptedString.of("On Left Click"), true)
			.setDescription(EncryptedString.of("Only attacks while left click is held"));
	public final NumberSetting groundCooldown = new NumberSetting(EncryptedString.of("Ground Cooldown"), 0, 100, 40, 1);
	public final NumberSetting groundRandom = new NumberSetting(EncryptedString.of("Ground Random"), 0, 50, 10, 1);
	public final NumberSetting airCooldown = new NumberSetting(EncryptedString.of("Air Cooldown"), 0, 100, 40, 1);
	public final NumberSetting airRandom = new NumberSetting(EncryptedString.of("Air Random"), 0, 50, 10, 1);
	public final BooleanSetting lockOnMode = new BooleanSetting(EncryptedString.of("Lock On Mode"), false)
			.setDescription(EncryptedString.of("Keeps one player locked and hits him while he is in Lock Range (crosshair not needed)"));
	public final NumberSetting lockRange = new NumberSetting(EncryptedString.of("Lock Range"), 1, 6, 4, 0.1);
	public final BooleanSetting clickSimulation = new BooleanSetting(EncryptedString.of("Click Simulation"), true);

	public static PlayerEntity staticLockedTarget;
	public boolean ignoreNextAttackEvent;

	public RexyTriggerBot() {
		super(EncryptedString.of("Rexy Trigger Bot"),
				EncryptedString.of("Rexy style trigger bot (random per-tick timing)"),
				-1,
				Category.sword);
		addSettings(checkSword, checkShield, checkUsing, checkScreen, checkHealth, checkFriends, onLeftClick,
				groundCooldown, groundRandom, airCooldown, airRandom, lockOnMode, lockRange, clickSimulation);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		eventManager.add(AttackListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		eventManager.remove(AttackListener.class, this);
		staticLockedTarget = null;
		super.onDisable();
	}

	public boolean groundCooldownThreshold() {
		return Math.random() < (groundCooldown.getValue() + groundRandom.getValue() * Math.random()) / 100.0;
	}

	public boolean airCooldownThreshold() {
		return Math.random() < (airCooldown.getValue() + airRandom.getValue() * Math.random()) / 100.0;
	}

	@Override
	public void onTick() {
		if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

		if (checkScreen.getValue() && mc.currentScreen != null) return;

		if (checkSword.getValue()) {
			Item item = mc.player.getMainHandStack().getItem();
			if (!InventoryUtils.isSword(item) && !(item instanceof AxeItem)) return;
		}

		if (checkUsing.getValue() && mc.player.isUsingItem()) return;
		if (checkShield.getValue() && mc.player.isBlocking()) return;

		if (onLeftClick.getValue() && GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			return;

		Entity target = lockOnMode.getValue() ? lockedTarget() : crosshairTarget();
		if (target == null) return;

		if (checkHealth.getValue() && (!target.isAlive() || (target instanceof LivingEntity le && le.getHealth() <= 0.0f)))
			return;
		if (checkFriends.getValue() && target instanceof PlayerEntity p && system.INSTANCE.getFriendManager().isFriend(p))
			return;

		// attack must be charged, then a random chance per tick decides when it fires
		if (mc.player.getAttackCooldownProgress(0.5f) < 0.95f) return;
		boolean fire = mc.player.isOnGround() ? groundCooldownThreshold() : airCooldownThreshold();
		if (!fire) return;

		WorldUtils.hitEntity(target, true);
		if (clickSimulation.getValue()) {
			MouseSimulation.mouseClick(GLFW.GLFW_MOUSE_BUTTON_LEFT);
		}
	}

	private Entity crosshairTarget() {
		if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof PlayerEntity p && p != mc.player) {
			return p;
		}
		return null;
	}

	/** Keeps the same player locked until he dies / leaves the range, then locks the closest one. */
	private Entity lockedTarget() {
		Vec3d eye = mc.player.getEyePos();
		double maxSq = lockRange.getValue() * lockRange.getValue();

		PlayerEntity locked = staticLockedTarget;
		if (locked != null && (!locked.isAlive() || locked.isRemoved() || distSq(eye, locked.getBoundingBox()) > maxSq)) {
			locked = null;
		}

		if (locked == null) {
			double best = maxSq;
			for (PlayerEntity p : mc.world.getPlayers()) {
				if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
				if (checkFriends.getValue() && system.INSTANCE.getFriendManager().isFriend(p)) continue;
				double d = distSq(eye, p.getBoundingBox());
				if (d <= best) {
					best = d;
					locked = p;
				}
			}
		}

		staticLockedTarget = locked;
		return locked;
	}

	private static double distSq(Vec3d p, Box b) {
		double dx = Math.max(Math.max(b.minX - p.x, 0), p.x - b.maxX);
		double dy = Math.max(Math.max(b.minY - p.y, 0), p.y - b.maxY);
		double dz = Math.max(Math.max(b.minZ - p.z, 0), p.z - b.maxZ);
		return dx * dx + dy * dy + dz * dz;
	}

	/** The simulated click goes through the normal attack path; only your real left click may attack on its own. */
	@Override
	public void onAttack(AttackEvent event) {
		if (SwapGuard.internalAttack) return;
		if (ignoreNextAttackEvent) {
			ignoreNextAttackEvent = false;
			return;
		}
		if (GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_PRESS)
			event.cancel();
	}
}
