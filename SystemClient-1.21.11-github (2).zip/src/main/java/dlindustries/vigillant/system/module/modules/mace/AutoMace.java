package dlindustries.vigillant.system.module.modules.mace;

import dlindustries.vigillant.system.event.events.AttackListener;
import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.ItemSwapper;
import dlindustries.vigillant.system.utils.SwapGuard;
import dlindustries.vigillant.system.utils.WorldUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Whatever item is in your hand: the mace is swapped in, the target is hit with it, and everything is swapped back
 * (through the shared ItemSwapper, so it never fights with SpearLunge).
 *
 * Works from ANY direction (falling from above, lunging in from the side, ...): the hit does not depend on fall distance.
 */
public final class AutoMace extends Module implements AttackListener, TickListener {
	private final ModeSetting<ItemSwapper.Mode> swapMode = new ModeSetting<>(EncryptedString.of("Swap Mode"), ItemSwapper.Mode.HandSwap, ItemSwapper.Mode.class)
			.setDescription(EncryptedString.of("Hand Swap: mace swaps places with the item in your hand (works from the inventory too). Hotbar: only selects the mace slot"));
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true)
			.setDescription(EncryptedString.of("Put your items back after the hit"));
	private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0, 10, 2, 1)
			.setDescription(EncryptedString.of("Ticks to keep the mace after the hit"));
	private final BooleanSetting onlyPlayers = new BooleanSetting(EncryptedString.of("Only Players"), true);
	private final BooleanSetting autoAttack = new BooleanSetting(EncryptedString.of("Auto Attack"), true)
			.setDescription(EncryptedString.of("Swaps to the mace and hits by itself (after a lunge, while falling, from any side)"));
	private final BooleanSetting anyDirection = new BooleanSetting(EncryptedString.of("Any Direction"), true)
			.setDescription(EncryptedString.of("Also hits a player that is in reach but not exactly in your crosshair"));
	private final NumberSetting range = new NumberSetting(EncryptedString.of("Range"), 2, 6, 3, 0.1)
			.setDescription(EncryptedString.of("Reach used by Any Direction"));
	private final NumberSetting hitDelay = new NumberSetting(EncryptedString.of("Hit Delay"), 0, 20, 8, 1)
			.setDescription(EncryptedString.of("Ticks between automatic hits"));
	private final NumberSetting minCharge = new NumberSetting(EncryptedString.of("Min Charge"), 0, 1, 0, 0.05)
			.setDescription(EncryptedString.of("Attack charge needed (swapping items resets it, so keep this low)"));
	private final BooleanSetting requireFall = new BooleanSetting(EncryptedString.of("Require Fall"), false)
			.setDescription(EncryptedString.of("Only swap to the mace while falling"));
	private final NumberSetting minFall = new NumberSetting(EncryptedString.of("Min Fall"), 0, 10, 1.5, 0.5)
			.setDescription(EncryptedString.of("Minimum fall distance for Require Fall"));

	private int hitTimer;

	public AutoMace() {
		super(EncryptedString.of("Auto Mace"),
				EncryptedString.of("Swaps the mace into your hand (whatever you hold) and hits the target"),
				-1,
				Category.mace);
		addSettings(swapMode, switchBack, switchDelay, onlyPlayers, autoAttack, anyDirection, range, hitDelay, minCharge, requireFall, minFall);
	}

	@Override
	public void onEnable() {
		eventManager.add(AttackListener.class, this);
		eventManager.add(TickListener.class, this);
		hitTimer = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(AttackListener.class, this);
		eventManager.remove(TickListener.class, this);
		ItemSwapper.restoreAll();
		super.onDisable();
	}

	/** Your own left click: whatever you hold turns into the mace for that hit. */
	@Override
	public void onAttack(AttackEvent event) {
		if (SwapGuard.internalAttack || SpearLunge.isBusy()) return;
		if (mc.player == null || mc.currentScreen != null) return;
		if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
		if (!isValidTarget(hit.getEntity())) return;

		equipMace();
	}

	@Override
	public void onTick() {
		ItemSwapper.tick();
		if (mc.player == null || mc.world == null) return;

		if (hitTimer > 0) hitTimer--;

		if (!autoAttack.getValue() || mc.currentScreen != null) return;
		if (SpearLunge.isBusy() || hitTimer > 0) return;

		Entity target = findTarget();
		if (target == null) return;
		if (mc.player.getAttackCooldownProgress(0.5f) < minCharge.getValueFloat()) return;

		if (equipMace()) {
			WorldUtils.hitEntity(target, true);
			hitTimer = hitDelay.getValueInt();
		}
	}

	/** Crosshair target first, then (Any Direction) the closest valid player in reach from any side. */
	private Entity findTarget() {
		if (mc.crosshairTarget instanceof EntityHitResult hit && isValidTarget(hit.getEntity())) {
			return hit.getEntity();
		}
		if (!anyDirection.getValue()) return null;

		Vec3d eye = mc.player.getEyePos();
		double maxSq = range.getValue() * range.getValue();
		Entity best = null;
		double bestSq = maxSq;

		for (Entity entity : mc.world.getEntities()) {
			if (!isValidTarget(entity)) continue;
			double sq = distanceSqToBox(eye, entity.getBoundingBox());
			if (sq <= bestSq) {
				bestSq = sq;
				best = entity;
			}
		}
		return best;
	}

	private static double distanceSqToBox(Vec3d p, Box b) {
		double dx = Math.max(Math.max(b.minX - p.x, 0), p.x - b.maxX);
		double dy = Math.max(Math.max(b.minY - p.y, 0), p.y - b.maxY);
		double dz = Math.max(Math.max(b.minZ - p.z, 0), p.z - b.maxZ);
		return dx * dx + dy * dy + dz * dz;
	}

	/** @return true if the mace is in the hand now */
	private boolean equipMace() {
		if (requireFall.getValue() && mc.player.fallDistance < minFall.getValueFloat()) return false;

		if (!ItemSwapper.equip(AutoMace::maceScore, swapMode.getMode(), switchDelay.getValueInt() + 1)) return false;

		if (!switchBack.getValue()) {
			ItemSwapper.forgetAll();
		}
		return true;
	}

	private boolean isValidTarget(Entity entity) {
		if (entity == null || entity == mc.player || !entity.isAlive()) return false;
		if (!(entity instanceof LivingEntity)) return false;
		if (entity instanceof PlayerEntity player && player.isSpectator()) return false;
		return !onlyPlayers.getValue() || entity instanceof PlayerEntity;
	}

	private static int maceScore(ItemStack stack) {
		return !stack.isEmpty() && stack.isOf(Items.MACE) ? 1 : -1;
	}
}
